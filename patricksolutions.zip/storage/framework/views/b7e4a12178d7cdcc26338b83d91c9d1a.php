<!DOCTYPE html>
<html lang="en">
<head>

     <title><?php echo $__env->yieldContent('title'); ?></title>

     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="shortcut icon" href="<?php echo e(asset('assets/logos/patrick_logo.png')); ?>" type="image/x-icon">
     <link rel="stylesheet" href="<?php echo e(asset ('assets/css/bootstrap.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset ('assets/css/font-awesome.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset ('assets/css/owl.carousel.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset ('assets/css/owl.theme.default.min.css')); ?>">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
     <!-- CK editor-->
     <link rel="stylesheet" href="https://cdn.ckeditor.com/ckeditor5/42.0.0/ckeditor5.css" />
     <link rel="stylesheet" href="https://cdn.ckeditor.com/ckeditor5-premium-features/42.0.0/ckeditor5-premium-features.css" />
     <script type="importmap">
       {
           "imports": {
               "ckeditor5": "https://cdn.ckeditor.com/ckeditor5/42.0.0/ckeditor5.js",
               "ckeditor5/": "https://cdn.ckeditor.com/ckeditor5/42.0.0/",
               "ckeditor5-premium-features": "https://cdn.ckeditor.com/ckeditor5-premium-features/42.0.0/ckeditor5-premium-features.js",
               "ckeditor5-premium-features/": "https://cdn.ckeditor.com/ckeditor5-premium-features/42.0.0/"
           }
       }
   </script>
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>
     <!-- MENU -->
<?php echo $__env->make('blog.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>

     <!-- FOOTER -->
   <?php echo $__env->make('blog.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- SCRIPTS -->
     <script src="<?php echo e(asset ('assets/js/jquery.js')); ?>"></script>
     <script src="<?php echo e(asset ('assets/js/bootstrap.min.js')); ?>"></script>
     <script src="<?php echo e(asset ('assets/js/owl.carousel.min.js')); ?>"></script>
     <script src="<?php echo e(asset ('assets/js/smoothscroll.js')); ?>"></script>
     <script src="<?php echo e(asset ('assets/js/custom.js')); ?>"></script>
     <script type="module" src="<?php echo e(asset('assets/vendor/ckeditor.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\V8\resources\views/blog/components/base.blade.php ENDPATH**/ ?>