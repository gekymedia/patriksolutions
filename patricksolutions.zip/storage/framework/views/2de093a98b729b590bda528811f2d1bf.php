<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Courses at Patrik Solutions')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-12">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <p class="login-box-msg"><?php echo $__env->make('message.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>

                        <form action="<?php echo e(route('lesson.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div>
                                <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                                
                                <label for="lesson_title" class="form-lable"> Lesson Title </label>
                                <input type="text" name="lesson_title" id="lesson_title" class="form-control"
                                    placeholder="Enter Lesson Title ...">
                                <?php if($errors->has('lesson_title')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('lesson_title')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div>

                                <label for="description" class="form-label">Description</label>
                                <textarea name="lesson_description" id="description" class="form-control rich-text"></textarea>

                                <?php if($errors->has('lesson_description')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('lesson_description')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div>
                                <label for="lesson_video" class="form-lable"> Lesson Videon </label>
                                <input type="file" name="lesson_video" id="lesson_video" class="form-control"
                                    placeholder="Upload Lesson Video Image ...">
                                <?php if($errors->has('lesson_video')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('lesson_video')); ?></span>
                                <?php endif; ?>
                            </div>

                            <button class=" btn btn-primary"> Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Include the CKEditor 5 script -->
    <script src="https://cdn.ckeditor.com/ckeditor5/34.2.0/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#description'))
            .catch(error => {
                console.error(error);
            });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\V8\resources\views/lesson/create.blade.php ENDPATH**/ ?>