<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mortgage Calculator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- External Font & CSS Libraries -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7fc;
            color: #333;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #4e73df;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 30px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-size: 1rem;
            font-weight: 600;
            color: #555;
        }

        input,
        select {
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            outline: none;
            transition: border-color 0.3s ease;
        }

        input:focus,
        select:focus {
            border-color: #4e73df;
        }

        button {
            padding: 12px;
            background-color: #4e73df;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #375a94;
        }

        #results {
            margin-top: 20px;
            padding: 20px;
            background-color: #f8f9fc;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        #results h3 {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
        }

        #results p {
            font-size: 1rem;
            margin: 5px 0;
        }

        .result-label {
            font-weight: 600;
            color: #4e73df;
        }

        .result-value {
            font-weight: 700;
            color: #333;
        }

        .row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .row p {
            font-size: 1rem;
        }

      

        /* Section Wrapper */
        .mortgage-terms {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        section {
            padding: 20px;
            margin: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Headings */
        .mortgage-terms h2 {
            font-size: 2rem;
            text-align: center;
            color: #2980b9;
            margin-bottom: 20px;
        }

        .term h3 {
            font-size: 1.4rem;
            margin-bottom: 10px;
            color: #27ae60;
            border-bottom: 2px solid #27ae60;
            display: inline-block;
            padding-bottom: 5px;
        }

        /* Paragraphs */
        section p {
            margin: 10px 0;
            color: #555;
        }

        /* Two-Column Layout for Larger Screens */
        .mortgage-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }

        @media (min-width: 768px) {
            .mortgage-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            section {
                padding: 15px;
            }

            .term h3 {
                font-size: 1.2rem;
            }

            .navbar .container-fluid {
                display: flex;
                justify-content: space-between;
            }
        }

        /* Add a subtle hover effect for sections */
        section:hover {
            background-color: #ecf0f1;
            border-color: #bdc3c7;
        }

        /* Center the navbar items */
        .navbar .container-fluid {
            display: flex;
            justify-content: center;
        }

        #navbarScroll .d-flex {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Add a hover effect for the navbar links */
        .nav-link {
            transition: all 0.3s ease;
            /* Smooth transition */
        }

        /* Hover effect for navbar links */
        .nav-link:hover {
            color: #28a745;
            /* Change to green or your preferred hover color */
            /* text-decoration: underline; */
            /* Optional: underline effect on hover */
        }

        @media (max-width: 768px) {

            /* Reduce padding for navbar on smaller screens */
            .navbar {
                padding-left: 10px;
                padding-right: 10px;
            }

            .navbar-nav {
                margin-left: 0;
                margin-right: 0;
            }

            .container-fluid {
                padding-left: 0;
                padding-right: 0;
            }

            .navbar-toggler {
                margin-right: 0;
            }

            .logo-spacing {
                margin-left: 10px;
            }

            /* Center the navbar items */
            .navbar .container-fluid {
                display: flex;
                justify-content: space-between;
            }
        }
        #mortgage-calculator-description {
  padding: 20px;
  text-align: center;
  /* background-color: #f4f4f4; */
  border-radius: 8px;
}

#mortgage-calculator-description h2 {
  color: #333;
  font-size: 20px;
}

#mortgage-calculator-description p {
  color: #666;
  font-size: 16px;
}

    </style>

</head>

<body>
   <?php echo $__env->make('calculator-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div id="mortgage-calculator-description">
  <h1>Mortgage Calculator</h1>
  <p>Use our mortgage calculator to get an idea of your monthly payment by adjusting the interest rate, down payment, home price and more. <br> To find out how you can pay off your mortgage faster, try our mortgage payoff calculator.</p>
</div>
    <div class="container">
        <h2>Mortgage Calculator</h2>

        <form id="mortgage-form">
            <div class="row">
                <div class="col">
                    <label for="home_value">Home Value ($)</label>
                    <input type="number" id="home_value" name="home_value" value="200000" />
                </div>
                <div class="col">
                    <label for="down_payment_amount">Down Payment Amount ($)</label>
                    <input type="number" id="down_payment_amount" name="down_payment_amount" value="40000" />
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <label for="down_payment_percentage">Down Payment Percentage (%)</label>
                    <input type="number" id="down_payment_percentage" name="down_payment_percentage" value="20" min="0"
                        max="100" />
                </div>
                <div class="col">
                    <label for="interest_rate">Interest Rate (%)</label>
                    <input type="decimal" id="interest_rate" name="interest_rate" value="6.5" min="0" max="100"
                        step="0.01" />
                </div>
            </div>

            <label for="mortgage_type">Mortgage Type</label>
            <select id="mortgage_type" name="mortgage_type">
                <option value="15_year" selected>15-year Fixed</option>
                <option value="30_year">30-year Fixed</option>
            </select>

            <div class="row">
                <div class="col">
                    <label for="property_taxes">Property Taxes ($)</label>
                    <input type="number" id="property_taxes" name="property_taxes" value="183" />
                </div>
                <div class="col">
                    <label for="home_insurance">Home Insurance ($)</label>
                    <input type="number" id="home_insurance" name="home_insurance" value="125" />
                </div>
            </div>

            <label for="hoa_dues">HOA Dues ($)</label>
            <input type="number" id="hoa_dues" name="hoa_dues" value="100" />

            <button type="submit">Calculate</button>
        </form>

        <div id="results">
            <h3>Results:</h3>
            <p><span class="result-label">Principal & Interest:</span> <span class="result-value"
                    id="principal_interest">$0.00</span></p>
            <p><span class="result-label">Property Taxes:</span> <span class="result-value"
                    id="property_taxes_result">$0.00</span></p>
            <p><span class="result-label">Home Insurance:</span> <span class="result-value"
                    id="home_insurance_result">$0.00</span></p>
            <p><span class="result-label">HOA Dues:</span> <span class="result-value" id="hoa_dues_result">$0.00</span>
            </p>
            <p><span class="result-label">Total Monthly Payment:</span> <span class="result-value"
                    id="total_payment">$0.00</span></p>
        </div>
    </div>
    <div class="mortgage-terms">
        <h2>Explanation of Mortgage Terms</h2>
        <div class="mortgage-grid">
            <section>
                <h3>Home Price</h3>
                <p>
                    Across the country, average home prices have been going up. Despite the rise in home prices, you can
                    still find a perfect home that’s within your budget! As you begin to house hunt, just make sure to
                    consider the most important question: <strong>How much house can I afford?</strong>
                </p>
            </section>

            <section>
                <h3>Down Payment</h3>
                <p>
                    The initial cash payment, usually represented as a percentage of the total purchase price, a home
                    buyer makes when purchasing a home. For example, a 20% down payment on a $200,000 house is $40,000.
                </p>
            </section>

            <section>
                <h3>Mortgage Types</h3>
                <p>
                    Learn the differences between <strong>15-Year Fixed-Rate Mortgage</strong>, <strong>30-Year
                        Fixed-Rate Mortgage</strong>, and <strong>5/1 Adjustable-Rate Mortgage (ARM)</strong>.
                </p>
            </section>

            <section>
                <h3>Interest Rate</h3>
                <p>
                    The ongoing cost of financing a home purchase, generally shown as an annual percentage of the
                    outstanding loan.
                </p>
            </section>

            <section>
                <h3>Private Mortgage Insurance (PMI)</h3>
                <p>
                    This extra cost is added to your monthly payment to protect the lender if you don’t pay your
                    mortgage. Avoid PMI with at least 20% down.
                </p>
            </section>

            <section>
                <h3>Homeowner’s Insurance</h3>
                <p>
                    Covers damages to your home from events like fire, windstorms, or theft, as well as possessions
                    inside your home.
                </p>
            </section>
        </div>
    </div>


    <section class="mortgage-uses bg-gray-100 py-10 px-5 rounded-lg ">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-8">How to Make the Most of Your Mortgage Calculator
        </h2>
        <div class="accordion" id="mortgageUsesAccordion">
            <!-- Understand Your Mortgage Payment -->
            <div class="accordion-item mb-4">
                <h3 class="accordion-header">
                    <button class="accordion-button bg-white text-gray-800 font-semibold rounded-lg" type="button"
                        data-bs-toggle="collapse" data-bs-target="#paymentBreakdown" aria-expanded="true"
                        aria-controls="paymentBreakdown">
                        Understand Your Mortgage Payment
                    </button>
                </h3>
                <div id="paymentBreakdown" class="accordion-collapse collapse show">
                    <div class="accordion-body text-gray-600 bg-white p-4">
                        A monthly mortgage payment is made up of several costs:
                        <ul class="list-disc pl-5 mt-2">
                            <li><strong>Principal & Interest (P&I):</strong> The repayment of your loan and interest.
                            </li>
                            <li><strong>Taxes:</strong> Property taxes based on your home’s value.</li>
                            <li><strong>Insurance:</strong> Homeowner’s insurance to protect your property.</li>
                            <li><strong>PMI:</strong> Private Mortgage Insurance, if applicable.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Compare Different Mortgage Types -->
            <div class="accordion-item mb-4">
                <h3 class="accordion-header">
                    <button class="accordion-button collapsed bg-white text-gray-800 font-semibold rounded-lg"
                        type="button" data-bs-toggle="collapse" data-bs-target="#compareMortgages" aria-expanded="false"
                        aria-controls="compareMortgages">
                        Compare Different Mortgage Types
                    </button>
                </h3>
                <div id="compareMortgages" class="accordion-collapse collapse">
                    <div class="accordion-body text-gray-600 bg-white p-4">
                        Compare the costs of different loan types:
                        <ul class="list-disc pl-5 mt-2">
                            <li>Estimate total interest paid for a 15-year vs. 30-year mortgage.</li>
                            <li>See how shorter loan durations save you money over time.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Calculate Your Down Payment -->
            <div class="accordion-item mb-4">
                <h3 class="accordion-header">
                    <button class="accordion-button collapsed bg-white text-gray-800 font-semibold rounded-lg"
                        type="button" data-bs-toggle="collapse" data-bs-target="#downPaymentImpact"
                        aria-expanded="false" aria-controls="downPaymentImpact">
                        Calculate Your Down Payment
                    </button>
                </h3>
                <div id="downPaymentImpact" class="accordion-collapse collapse">
                    <div class="accordion-body text-gray-600 bg-white p-4">
                        Adjust your down payment to see how it affects:
                        <ul class="list-disc pl-5 mt-2">
                            <li>Your monthly payment.</li>
                            <li>Private Mortgage Insurance (PMI) requirements.</li>
                            <li>Loan qualification criteria.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-8">
            <a href="#" class="bg-blue-600 text-white py-2 px-5 rounded-lg shadow-md hover:bg-blue-500">
                Get Pre-Approved Now
            </a>
        </div>
    </section>

    <script>
        $(document).ready(function () {
            // Handle form submission
            $('#mortgage-form').on('submit', function (event) {
                event.preventDefault();

                const homeValue = parseFloat($('#home_value').val());
                const downPaymentAmount = parseFloat($('#down_payment_amount').val());
                const downPaymentPercentage = parseFloat($('#down_payment_percentage').val()) / 100;
                const interestRate = parseFloat($('#interest_rate').val()) / 100;
                const mortgageType = $('#mortgage_type').val();
                const propertyTaxes = parseFloat($('#property_taxes').val());
                const homeInsurance = parseFloat($('#home_insurance').val());
                const hoaDues = parseFloat($('#hoa_dues').val());

                // Calculate the loan amount
                const loanAmount = homeValue - downPaymentAmount;
                const loanTerm = mortgageType === '15_year' ? 15 * 12 : 30 * 12; // 15 years or 30 years
                const monthlyRate = interestRate / 12;

                // Calculate the monthly payment (Principal + Interest)
                const principalAndInterest = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, loanTerm)) / (Math.pow(1 + monthlyRate, loanTerm) - 1);

                // Calculate total payment
                const totalMonthlyPayment = principalAndInterest + propertyTaxes + homeInsurance + hoaDues;

                // Update results
                $('#principal_interest').text(principalAndInterest.toFixed(2));
                $('#property_taxes_result').text(propertyTaxes.toFixed(2));
                $('#home_insurance_result').text(homeInsurance.toFixed(2));
                $('#hoa_dues_result').text(hoaDues.toFixed(2));
                $('#total_payment').text(totalMonthlyPayment.toFixed(2));
            });
        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/mortgage_calculator.blade.php ENDPATH**/ ?>