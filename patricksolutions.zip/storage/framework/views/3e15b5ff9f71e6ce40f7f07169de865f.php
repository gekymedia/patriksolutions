<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mortgage Payoff Calculator</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>"> <!-- Custom Styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #007bff;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        .container {
            padding: 20px;
            max-width: 1200px;
            margin: auto;
        }
        .calculator-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        label, input, button {
            display: block;
            margin-bottom: 15px;
            width: 100%;
        }
        input[type="number"] {
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .result {
            margin-top: 20px;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <header>
        <h1>Mortgage Payoff Calculator</h1>
    </header>
    <div class="container">
        <div class="calculator-container">
            <p>Use our mortgage payoff calculator to see how quickly you can pay off your mortgage based on your current loan balance, interest rate, and monthly payment.</p>

            <form id="mortgage-form">
                <label for="loan_balance">Loan Balance ($):</label>
                <input type="number" id="loan_balance" name="loan_balance" value="300000" min="0" required>

                <label for="interest_rate">Annual Interest Rate (%):</label>
                <input type="number" id="interest_rate" name="interest_rate" value="4.5" min="0" required>

                <label for="monthly_payment">Monthly Payment ($):</label>
                <input type="number" id="monthly_payment" name="monthly_payment" value="1500" min="0" required>

                <button type="submit">Calculate Payoff Date</button>
            </form>

            <div class="result" id="result" style="display: none;">
                <h4>Mortgage Payoff Date: <span id="payoff_date"></span></h4>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('mortgage-form').addEventListener('submit', function(e) {
            e.preventDefault();

            let loanBalance = parseFloat(document.getElementById('loan_balance').value);
            let interestRate = parseFloat(document.getElementById('interest_rate').value) / 100 / 12;
            let monthlyPayment = parseFloat(document.getElementById('monthly_payment').value);

            if (loanBalance <= 0 || interestRate <= 0 || monthlyPayment <= 0) {
                alert("Please enter valid values.");
                return;
            }

            let months = 0;
            let balance = loanBalance;

            while (balance > 0) {
                let interest = balance * interestRate;
                let principal = monthlyPayment - interest;

                if (principal <= 0) {
                    alert("The monthly payment is too low to cover the interest. Please enter a higher amount.");
                    return;
                }

                balance -= principal;
                months++;

                if (balance < 0) {
                    balance = 0;
                }
            }

            let monthsToPayoff = months;
            let currentDate = new Date();
            currentDate.setMonth(currentDate.getMonth() + monthsToPayoff);
            let payoffDate = currentDate.toLocaleDateString();

            document.getElementById('payoff_date').textContent = payoffDate;
            document.getElementById('result').style.display = 'block';
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/mortgage_payoff_calculator.blade.php ENDPATH**/ ?>