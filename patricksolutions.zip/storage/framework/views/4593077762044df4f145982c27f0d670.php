
<?php $__env->startSection('title', 'Patrik Solutions | Courses '); ?>

<?php $__env->startSection('content-action'); ?>
    <a href="<?php echo e(route('course.create')); ?>" class="btn btn-info">Add New</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <div class="table-responsive-lg">
            <p class="login-box-msg"> <?php echo $__env->make('message.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </p>
            <table>

                <thead>
                    <tr>
                        <th> No.</th>
                        <th> Course Name.</th>
                        <th> Course Description</th>
                        <th> Course Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th> <?php echo e($course->id); ?></th>
                            <td> <?php echo e($course->course_name); ?></td>
                            <td> <?php echo e($course->course_description); ?></td>
                            <td> <img src="<?php echo e($course->course_image_url); ?>" alt=""></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.components.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/admin/course/index.blade.php ENDPATH**/ ?>