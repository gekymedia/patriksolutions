<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Courses at Patrik Solutions')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-12">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <p class="login-box-msg"><?php echo $__env->make('message.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>

                        <form action="<?php echo e(route('course.update', $course->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div >
                                <label for="course_name" class="form-lable"> Course Name </label>
                                <input type="text" name="course_name" value="<?php echo e($course->course_name); ?>" id="course_name" class="form-control"
                                    placeholder="Enter Course Name ...">
                                <?php if($errors->has('course_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('course_name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div>
                                <label for="course_description" class="form-lable"> Course Description </label>
                                <input type="text" name="course_description"  value="<?php echo e($course->course_description); ?>" id="course_description"
                                    class="form-control" placeholder="Enter Course Description ...">
                                <?php if($errors->has('course_description')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('course_description')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div>
                                <label for="course_image_url" class="form-lable"> Course Thumbnail </label>
                                <input type="file" name="course_image_url" id="course_image_url" class="form-control"
                                    placeholder="Upload Course Image ...">
                                <?php if($errors->has('course_image_url')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('course_image_url')); ?></span>
                                <?php endif; ?>
                            </div>

                            <button class=" btn btn-primary"> Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/course/edit.blade.php ENDPATH**/ ?>