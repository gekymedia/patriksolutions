
<?php $__env->startSection('title', 'Patrik Solutions | Courses '); ?>

<?php $__env->startSection('content'); ?>
 <form action="<?php echo e(route('course.store')); ?>" method="post">
        <p class="login-box-msg"><?php echo $__env->make('message.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body">
                <div class="col-md-4">
                    <label for="course_name" class="form-lable"> Course Name </label>
                    <input type="text" name="course_name" id="course_name" class="form-control" placeholder="Enter Course Name ...">
                    <?php if($errors->has('course_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('course_name')); ?></span>
                    <?php endif; ?>
                </div>
                <div>
                    <label for="course_description" class="form-lable"> Course Description </label>
                    <input type="text" name="course_description" id="course_description" class="form-control" placeholder="Enter Course Name ...">
                    <?php if($errors->has('course_description')): ?>
                        <span class="text-danger"><?php echo e($errors->first('course_description')); ?></span>
                    <?php endif; ?>
                    </div>
                <div>
                    <label for="course_image_url" class="form-lable"> Course Thumbnail </label>
                    <input type="file" name="course_image_url" id="course_image_url" class="form-control" placeholder="Upload Course Image ...">
                    <?php if($errors->has('course_image_url')): ?>
                    <span class="text-danger"><?php echo e($errors->first('course_image_url')); ?></span>
                <?php endif; ?>
                </div>

                <button class=" btn btn-primary"> Save</button>
            </div>
        </div>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.components.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/admin/course/create.blade.php ENDPATH**/ ?>