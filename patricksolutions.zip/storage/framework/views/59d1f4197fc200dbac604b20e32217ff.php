
<?php $__env->startSection('title', 'Patrick Solutions | Blog Post Details'); ?>
<?php $__env->startSection('contact-active', 'active'); ?>
<?php $__env->startSection('content'); ?>
<section>
     <div class="container">
          <div class="text-center">
               <h1>Contact Us</h1>

               <br>

               <p class="lead">Want to reach us? Send us a Message</p>
          </div>
     </div>
</section>


<!-- CONTACT -->
<section id="contact">
     <div class="container">
          <div class="row">

               <div class="col-md-6 col-sm-12">
                    <form id="contact-form" role="form" action="<?php echo e(route('contact.us')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                         <div class="col-md-12 col-sm-12">
                              <input type="text" class="form-control" placeholder="Enter full name" name="name" required>
               
                              <input type="email" class="form-control" placeholder="Enter email address" name="email" required>

                              <textarea class="form-control" rows="6" placeholder="Tell us about your message" name="message" required></textarea>
                         </div>

                         <div class="col-md-4 col-sm-12">
                              <input type="submit" class="form-control" name="send message" value="Send Message">
                         </div>

                    </form>
               </div>

               <div class="col-md-6 col-sm-12">
                    <div class="contact-image">
                         <img src="images/contact-1-600x400.jpg" class="img-responsive" alt="">
                    </div>
               </div>

          </div>
     </div>
</section>       

<?php $__env->stopSection(); ?>


<?php echo $__env->make('blog.components.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/blog/contact.blade.php ENDPATH**/ ?>