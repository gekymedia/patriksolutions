<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Your Course at Patrik Solutions')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <a href="<?php echo e(route('course.register.create')); ?>" class="btn btn-primary mb-4">Add New Room</a>
                <a href="#" class="btn btn-primary mb-4"><i class="fas fa-dashboard"></i> Dashboard</a>
                <div class="table-responsive">
                    <?php if($courseregistration->isEmpty()): ?>
                        <p>You haven't joined any of Patrik Solues course</p>
                        <a href="<?php echo e(route('course.index')); ?>"> View Available courses</a>
                    <?php else: ?>
                      <div class="row justify-content-center g-4 mb-4">
                            <div class="col-md-6 col-lg-4 mb-2">
                                <div class="card h-100 shadow">
                                    <div class="card-body d-flex flex-column black-card">
                                        <h3 class="card-title text-success">
                                            <i class="fas fa-tachometer-alt fa-1x mb-3"></i> Black-Task
                                        </h3>
                                        <p class="card-text">
                                            Manage your black tasks efficiently with our comprehensive tracking system.
                                            Stay on top of deadlines and enhance productivity.
                                        </p>
                                        
                                            Black Task</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-4 mb-2">
                                <div class="card h-100 shadow">
                                    <div class="card-body d-flex flex-column presence-card">
                                        <h5 class="card-title text-warning">
                                            <i class="fas fa-eye fa-1x mb-3"></i> Presence-keep
                                        </h5>
                                        <p class="card-text">
                                            Track and record your presence with ease. Our tool ensures you never miss a
                                            moment and keeps accurate records for your needs.
                                        </p>
                                        <a href="<?php echo e(route('course.register.show')); ?>"class="btn btn-warning mt-auto text-white">Go to Presence Keeping</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Announcements Section -->
                            
                            <!-- Announcements Section End -->
                        </div>
                        
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/course_registration/index.blade.php ENDPATH**/ ?>