<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Blog Post')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <?php if(session('success')): ?>
                    <div class="bg-green-500 text-white p-4 mb-4 rounded">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="bg-red-500 text-white p-4 mb-4 rounded">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('blogs.update', $blog)); ?>" method="post" enctype="multipart/form-data">
                   <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class=" col-md-12">
                        <label for="blog_title" class="form-label"> Blog Title</label>
                        <input type="text" name="blog_title" value="<?php echo e($blog->blog_title); ?>" id="blog_title" class="form-control">
                        <?php if($errors->has('blog_title')): ?>
                            <span class="text-danger"><?php echo e($errors->first('blog_title')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <label for="blog_content" class="form-label">Blog Content</label>
                        <textarea name="blog_content" id="description" value="<?php echo e($blog->blog_content); ?>"  class="form-control rich-text"></textarea>
                        <?php if($errors->has('blog_content')): ?>
                        <span class="text-danger"><?php echo e($errors->first('blog_content')); ?></span>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <label for="blog_author" class="form-label">Blog Author</label>
                        <input type="text" name="blog_author" id="blog_author"  value="<?php echo e($blog->blog_author); ?>" class="form-control">
                        <?php if($errors->has('blog_author')): ?>
                        <span class="text-danger"><?php echo e($errors->first('blog_author')); ?></span>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <label for="blog_thumbnail" class="form-label">Blog Thumbnail</label>
                        <input type="file" name="blog_thumbnail" id="blog_thumbnail" class="form-control">
                        <?php if($errors->has('blog_thumbnail')): ?>
                        <span class="text-danger"><?php echo e($errors->first('blog_thumbnail')); ?></span>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <label for="blog_slug" class="form-label">Blog Slug</label>
                        <input type="text" name="blog_slug" id="blog_slug"   value="<?php echo e($blog->blog_slug); ?>" class="form-control">
                        <?php if($errors->has('blog_title')): ?>
                        <span class="text-danger"><?php echo e($errors->first('blog_slug')); ?></span>
                    <?php endif; ?> </div>
                    <div class="col-md-12">
                        <label for="blog_status" class="form-label">Blog Status</label>
                        <select name="blog_status" id="blog_status" class="form-control">
                            <option value="live">Live</option>
                            <option value="draft">Draft</option>
                        </select>
                        <?php if($errors->has('blog_status')): ?>
                        <span class="text-danger"><?php echo e($errors->first('blog_status')); ?></span>
                    <?php endif; ?></div>
                    <div class="col-md-12">
                        <label for="blog_view" class="form-label">Blog View</label>
                        <input type="number" name="blog_view" id="blog_view" value="<?php echo e($blog->blog_view); ?>"  class="form-control">
                        <?php if($errors->has('blog_view')): ?>
                        <span class="text-danger"><?php echo e($errors->first('blog_view')); ?></span>
                    <?php endif; ?></div>
                    <button class="btn btn-primary" type="submit">Submit</button>
                </form>
            </div>
        </div>
    </div>
     <!-- Include the CKEditor 5 script -->
     <script src="https://cdn.ckeditor.com/ckeditor5/34.2.0/classic/ckeditor.js"></script>
     <script>
         ClassicEditor
             .create(document.querySelector('#description'))
             .catch(error => {
                 console.error(error);
             });
     </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/admin/blog/edit.blade.php ENDPATH**/ ?>