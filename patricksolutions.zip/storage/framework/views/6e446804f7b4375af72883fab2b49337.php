
<?php $__env->startSection('title', 'Patrik Solutions | Courses '); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('user.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="col-md-4">
        <label for="name" class="form-label"> Name</label>
        <input type="text" name="name" id="name" class="form-control">
        <?php if($errors->has('name')): ?>
            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
    </div>
    <div class="col-md-4">
        <label for="role" class="form-label">Role</label>
        <input type="text" name="role" id="role" class="form-control">
        <?php if($errors->has('role')): ?>
        <span class="text-danger"><?php echo e($errors->first('role')); ?></span>
    <?php endif; ?>
    </div>
    <div class="col-md-4">
        <label for="email" class="form-label">Email</label>
        <input type="email" name="email" id="email" class="form-control">
        <?php if($errors->has('email')): ?>
        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
    <?php endif; ?>
    </div>
    <div class="col-md-4">
        <label for="photo" class="form-label">Upload Photo</label>
        <input type="file" name="photo" id="photo" class="form-control">
        <?php if($errors->has('photo')): ?>
        <span class="text-danger"><?php echo e($errors->first('photo')); ?></span>
    <?php endif; ?>
    </div>
    
    <div class="col-md-4">
        <label for="password" class="form-label">Upload Photo</label>
        <input type="password" name="password" id="password" class="form-control">
        <?php if($errors->has('password')): ?>
        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
    <?php endif; ?>
    </div>

    

    <button type="submit">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.components.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/admin/user/create.blade.php ENDPATH**/ ?>