<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Blog Posts')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary mb-4">Create New Blog</a>
                
                <div class="table-responsive">
                    <?php if($blogs->isEmpty()): ?>
                        <p>No Blogs Posted Yes</p>
                    <?php else: ?>
                    <table  class="table">
                        <thead>
                        <tr>
                            <th>No.</th>
                            <th>Title</th>
                            <th>Author.</th>
                            <th>Description</th>
                            <th>Thumbnail</th>
                            <th>Status</th>
                            <th>View</th>
                            <th>View</th>
                        </tr>    
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th>
                                <?php echo e($blog->id); ?>

                            </th>
                            <td>
                                <?php echo e($blog->blog_title); ?>

                            </td>
                            <td>
                                <?php echo e($blog->blog_author); ?>

                            </td>
                            <td>
                                <?php echo $blog->blog_content; ?>

                            </td>
                            <td>
                                <img src="<?php echo e(asset('storage/'.$blog->blog_thumbnail)); ?>" class="image-fluid" alt="Blog Thumbnail">
                                
                            </td>
                            <td>
                                <?php echo e($blog->blog_status); ?>

                            </td>
                            <td>
                                <?php echo e($blog->blog_view); ?>

                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-danger dropdown-toggle" type="button" id="actionsDropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Actions
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="actionsDropdownMenuButton">
                                        <a class="dropdown-item btn btn-info" href="<?php echo e(route('blog-details', $blog->id)); ?>"><i class="fas fa-eye"></i> View</a> 
                                        <a class="dropdown-item btn btn-success" href="<?php echo e(route('blogs.edit', $blog->id)); ?>"><i class="fas fa-pen"></i> Update</a>
                                        <div class="dropdown-divider"></div>
                                        <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger dropdown-item"><i class="fas fa-trash"></i> Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>