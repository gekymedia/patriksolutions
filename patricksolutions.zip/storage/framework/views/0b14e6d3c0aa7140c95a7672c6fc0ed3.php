<?php

$hour = date('G');
$minute = date('i');
$second = date('s');
$msg = ' Today is ' . date('l, M. d, Y.');

if ($hour >= 0 && $hour <= 9) {
    $greet = 'Good Morning,';
} elseif ($hour >= 10 && $hour <= 11) {
    $greet = 'Good Day,';
} elseif ($hour >= 12 && $hour <= 15) {
    $greet = 'Good Afternoon,';
} else {
    $greet = 'Good Evening,';
}
?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>GEKY MEDIA GHANA | STAFF</title>

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('asset/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/x-icon" sizes="32x32" href="<?php echo e(asset('asset/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/x-icon" sizes="16x16" href="<?php echo e(asset('asset/favicon-32x32.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('asset/site.webmanifest')); ?>">

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::to('assets/favicon.ico')); ?>">

    <link rel="icon" href="<?php echo e(asset('asset/favicon.png')); ?>" sizes="16x16" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" sizes="32x32" type="image/x-icon">
    <link rel="icon" href="GEKY MEDIA GHANA LOGO DESIGN.png" sizes="48x48" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body>
    <div class="container">
        <div id="app">
            <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm sticky-top">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('dashboard')); ?>">
                        
                        <?php echo e(Auth::user()->name); ?> Dashboard
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">
                            <!-- Add any additional links here -->
                        </ul>

                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ml-auto">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                    </a>

                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>

            <header class="bg-white shadow-sm py-3">
                <div class="container d-flex justify-content-between align-items-center">
                    <h4 class="page-title"><?php echo e($greet); ?> <?php echo e(Auth::user()->name); ?>!</h4>
                    <h6 class="text-muted"><?php echo e($msg); ?></h6>
                </div>
            </header>

            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>

</html>

<?php /**PATH /var/www/vhosts/gekymedia.com/patriksolutions.com/resources/views/partials/layouts.blade.php ENDPATH**/ ?>