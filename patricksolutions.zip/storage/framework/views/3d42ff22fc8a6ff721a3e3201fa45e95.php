

<img src="<?php echo e(asset('assets/logos/patrick_logo.png')); ?>" alt="" <?php echo e($attributes); ?>><?php /**PATH /var/www/vhosts/gekymedia.com/patriksolutions.com/resources/views/components/application-logo.blade.php ENDPATH**/ ?>