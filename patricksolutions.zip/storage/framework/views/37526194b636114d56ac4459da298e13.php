<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create Youtube Post')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
        <button type="button " class="close" data-dismiss='alert'> x
        </button>
        <strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?>
    <div class="container py-12">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <form action="<?php echo e(route('youtube.update', $youtube)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class=" col-md-12">
                                <label for="title" class="form-label"> Youtube Video Title</label>
                                <input type="text" name="title" id="title" value="<?php echo e($youtube->title); ?>" class="form-control">
                                <?php if($errors->has('title')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-12">
                                <label for="url" class="form-label">Youtube Embedded Link</label>
                                <input name="url" id="description"  value="<?php echo e($youtube->title); ?>"  class="form-control rich-text"></input>
                                <?php if($errors->has('url')): ?>
                                <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
                            <?php endif; ?>
                            </div>
                            <button class="btn btn-primary" type="submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include the CKEditor 5 script -->
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/vhosts/gekymedia.com/patriksolutions.com/resources/views/admin/youtube/edit.blade.php ENDPATH**/ ?>