
<?php $__env->startSection('title', 'Patrick Solutions | Blog Post'); ?>
<?php $__env->startSection('blog-active', 'active'); ?>
<?php $__env->startSection('content'); ?>

<section>
     <div class="container">
          <div class="text-center">
               <h1>Our Blog</h1>

               <br>

               <p class="lead">Read through some of the intresting topics on financial freedom from Patrik Barfi</p>
          </div>
     </div>
</section>

<section class="section-background">
     <div class="container">
          <div class="row">
               <div class="col-lg-3 pull-right col-xs-12">
                    <div class="form">
                         <form action="#">
                              <div class="form-group">
                                   <label class="control-label">Blog Search</label>

                                   <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Search for...">
                                        <span class="input-group-btn">
                                             <button class="btn btn-default" type="button">Go!</button>
                                        </span>
                                   </div>
                              </div>
                         </form>
                    </div>

                    <br>

                    <label class="control-label">Lorem ipsum dolor sit amet</label>

                    <ul class="list">
                         <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><a href="<?php echo e(route('blog-details', $blog->id)); ?>"><?php echo e($blog->blog_title); ?></a></li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
               </div>

               <div class="col-lg-9 col-xs-12">
                    <div class="row">

                         
                         <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="col-sm-6">
                              <div class="courses-thumb courses-thumb-secondary">
                                   <div class="courses-top">
                                        <div class="courses-image">
                                             <img src="<?php echo e(asset('storage/'.$blog->blog_thumbnail)); ?>" class="img-responsive" alt="">
                                        </div>
                                        <div class="courses-date">
                                             <span title="Author"><i class="fa fa-user"></i> <?php echo e($blog->blog_author); ?></span>
                                             <span title="Date"><i class="fa fa-calendar"></i> <?php echo e($blog->created_at); ?></span> 
                                             <span title="Views"><i class="fa fa-eye"></i> <?php echo e($blog->blog_view); ?></span>
                                        </div>
                                   </div>

                                   <div class="courses-detail">
                                        <h3><a href="<?php echo e(route('blog-details', $blog->id)); ?>"><?php echo e($blog->blog_title); ?></a></h3>
                                   </div>

                                   <div class="courses-info">
                                        <a href="<?php echo e(route('blog-details', $blog->id)); ?>" class="section-btn btn btn-primary btn-block">Read More</a>
                                   </div>
                              </div>
                         </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                         
                         
                    </div>
               </div>
          </div>
     </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.components.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\patriksolutions\resources\views/blog/blog-posts.blade.php ENDPATH**/ ?>