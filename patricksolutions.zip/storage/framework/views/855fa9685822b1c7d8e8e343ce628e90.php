

<img src="<?php echo e(asset('assets/logos/patrick_logo.png')); ?>" alt="" <?php echo e($attributes); ?>><?php /**PATH C:\xampp\htdocs\V8\resources\views/components/application-logo.blade.php ENDPATH**/ ?>