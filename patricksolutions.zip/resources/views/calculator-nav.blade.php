 <!-- Nav Start -->
 <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a href="{{ route('index') }}">
                <img src="{{ asset('assets/logos/patrick_logo.png') }}" alt="Logo" class="logo-spacing"
                    style="width: 50px; height: auto;">
            </a>

            <span>Patrik Solutions</span>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto d-flex justify-content-center">
                   
                    <x-nav-link :href="route('investment_calculator.index')"
                        :active="request()->routeIs('investment_calculator.index')" class="nav-link me-3">
                        {{ __('Investment Calculator') }}
                    </x-nav-link>
                    <x-nav-link :href="route('budget_calculator.index')"
                        :active="request()->routeIs('budget_calculator.index')" class="nav-link me-3">
                        {{ __('Budget Calculator') }}
                    </x-nav-link>
                    @auth
                    <x-nav-link :href="route('budget_calculator.list')"
                        :active="request()->routeIs('budget_calculator.list')" class="nav-link me-3">
                        {{ __('My Budgets') }}
                    </x-nav-link>
                    @endauth
                    <x-nav-link :href="route('retirement_calculator.index')"
                        :active="request()->routeIs('investment_calculator.index')" class="nav-link me-3">
                        {{ __('Retirement Calculator') }}
                    </x-nav-link>
                    <x-nav-link :href="route('mortgage-calculator')"
                        :active="request()->routeIs('mortgage-calculator')" class="nav-link me-3">
                        {{ __('Mortgage Calculator') }}
                    </x-nav-link>
                    @auth
                        @if (Auth::user()->role == 'admin')
                            <x-nav-link :href="route('blogs.index')" :active="request()->routeIs('blogs.index')"
                                class="nav-link me-3">
                                {{ __('Blogs') }}
                            </x-nav-link>
                            <x-nav-link :href="route('youtube.index')" :active="request()->routeIs('youtube.index')"
                                class="nav-link me-3">
                                {{ __('Youtube') }}
                            </x-nav-link>
                            <x-nav-link :href="route('contact.index')" :active="request()->routeIs('contact.index')"
                                class="nav-link me-3">
                                {{ __('Contact us') }}
                            </x-nav-link>
                        @endif
                    @endauth
                    <x-nav-link :href="route('course.index')" :active="request()->routeIs('course.index')"
                        class="nav-link me-3">
                        {{ __('Courses') }}
                    </x-nav-link>
                </div>
            </div>
        </div>
    </nav>
    <!-- End of Nav -->